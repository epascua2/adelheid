# Foam

Because switches don't clip into 3mm acrylic I'd recommed getting some plate foam cut.  
The height between the top of the plate and the PCB is 5 mm. For a 3 mm plate I would order 2 mm foam.

I have not tested the files. But they should be fine.

As a cheap alternative you could also cut an EVA foam sheet into strips and place them between the rows.
