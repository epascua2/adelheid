# 𝕬𝖉𝖊𝖑𝖍𝖊𝖎𝖉 - Case

## Lasercutable Layered Case

![high profile case top](https://gist.githubusercontent.com/floookay/7bf6511a8d84804d32de4d7bbe3bd0fb/raw/559336bcb5f8c04bbea9ad8aab7397812ab72859/case_wo_keycaps.jpg)  
[more information here](./lasercut-layers/README.md)

## 3D Printable Case

no ETA  
[more information here](./3d-printed/README.md)
